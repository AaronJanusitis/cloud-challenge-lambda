import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ResumeCounter')

def lambda_handler(event, context):
    response = table.get_item(Key={'CounterName':'Counter'})
    views = response['Item']['CounterNumber']
    views += 1
    table.put_item(Item= {'CounterName':'Counter','CounterNumber':views})
    print(views)
    
    return views